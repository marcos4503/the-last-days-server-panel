﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Media3D;

namespace SBUEditor.Scripts
{
    /*
     * This is the script responsible by interpretation of "BiomeMobWeight.csv" file
    */

    public class BiomeMobWeight
    {
        //Private classes
        public class SpawnData
        {
            //This class holds data of spawn

            //Public variables
            public string type = "";
            public string id = "";
            public string weight = "";
            public string minCount = "";
            public string maxCount = "";
        }

        //Private variables
        private string filePath = "";
        private List<string> commentLines = new List<string>();
        private Dictionary<string, List<SpawnData>> spawnDictionary = new Dictionary<string, List<SpawnData>>();

        //Core methods

        public BiomeMobWeight(string filePath)
        {
            //Save the data
            this.filePath = filePath;

            //Load the file
            string[] fileLines = File.ReadAllLines(filePath);

            //Process each line of file
            foreach (string line in fileLines)
            {
                //If is a comment line, skip it
                if (line[0] == '*')
                {
                    commentLines.Add(line);
                    continue;
                }

                //Divide the line
                string[] lineExploded = line.Split(", ");
                string biomeName = lineExploded[1];
                string biomeId = lineExploded[2];
                string creatureType = lineExploded[3];
                string creatureId = lineExploded[4];
                string creatureWeight = lineExploded[5];
                string creatureMinCount = lineExploded[6];
                string creatureMaxCount = lineExploded[7];

                //Add to the dictionary
                if (spawnDictionary.ContainsKey((biomeName + "/" + biomeId)) == false)
                    spawnDictionary.Add((biomeName + "/" + biomeId), new List<SpawnData>());
                SpawnData spawnData = new SpawnData();
                spawnData.type = creatureType;
                spawnData.id = creatureId;
                spawnData.weight = creatureWeight;
                spawnData.minCount = creatureMinCount;
                spawnData.maxCount = creatureMaxCount;
                spawnDictionary[(biomeName + "/" + biomeId)].Add(spawnData);
            }
        }

        public ref Dictionary<string, List<SpawnData>> GetSpawnDictionaryRef()
        {
            //Return reference for spawn dictionary
            return ref spawnDictionary;
        }
    
        public bool AddEntrieOnDividerKey(string dividerKey, string type, string creatureId, string weight, string countMin, string countMax)
        {
            //Prepare the result
            bool added = false;

            //Check if the entrie already exists in the divider key
            bool alreadyExists = false;
            foreach (SpawnData data in spawnDictionary[dividerKey])
                if (data.id == creatureId)
                    alreadyExists = true;

            //If already exists, cancel
            if (alreadyExists == true)
                return added;

            //Add this new entrie on the divider
            SpawnData spawnData = new SpawnData();
            spawnData.type = type;
            spawnData.id = creatureId;
            spawnData.weight = weight;
            spawnData.minCount = countMin;
            spawnData.maxCount = countMax;
            spawnDictionary[dividerKey].Add(spawnData);
            added = true;

            //Return the result
            return added;
        }

        public void EditEntrieOnDividerKey(string dividerKey, string whereCreatureIdIs, string newType, string newWeight, string newCountMin, string newCountMax)
        {
            //Find the id of the entrie to edit
            int idToEdit = -1;
            for (int i = 0; i < spawnDictionary[dividerKey].Count; i++)
                if (spawnDictionary[dividerKey][i].id == whereCreatureIdIs)
                {
                    idToEdit = i;
                    break;
                }

            //Edit the entrie, if found
            if (idToEdit != -1)
            {
                spawnDictionary[dividerKey][idToEdit].type = newType;
                spawnDictionary[dividerKey][idToEdit].weight = newWeight;
                spawnDictionary[dividerKey][idToEdit].minCount = newCountMin;
                spawnDictionary[dividerKey][idToEdit].maxCount = newCountMax;
            }
        }

        public void RemoveEntriesOfDividerKey(string dividerKey, string[] creatureIdsToRemove)
        {
            //Re-create the entrie in list
            List<string> creatureIdsToRemoveList = new List<string>();
            foreach (string id in creatureIdsToRemove)
                creatureIdsToRemoveList.Add(id);

            //Remove all entries of list
            while (creatureIdsToRemoveList.Count > 0)
            {
                //Get the first id of list
                string currentIdToRemove = creatureIdsToRemoveList[0];

                //Get the id of the entrie to remove
                int idToRemove = -1;
                for(int i = 0; i < spawnDictionary[dividerKey].Count; i++)
                    if (spawnDictionary[dividerKey][i].id == currentIdToRemove)
                    {
                        idToRemove = i;
                        break;
                    }

                //If was found some element, remove it
                if (idToRemove != -1)
                    spawnDictionary[dividerKey].RemoveAt(idToRemove);

                //Remove this first element
                creatureIdsToRemoveList.RemoveAt(0);
            }
        }
    
        public string[] AddEntrieToAllDividers(string type, string creatureId, string weight, string countMin, string countMax)
        {
            //Prepare the list of biomes that the new entrie was added
            List<string> biomesWhereAdded = new List<string>();

            //Process all dividers
            foreach (var item in spawnDictionary)
            {
                //Get current key
                string currentKey = item.Key;

                //Check if this divider already have the entrie inserted
                bool alreadyHave = false;
                foreach (SpawnData currentData in item.Value)
                    if (currentData.id == creatureId)
                    {
                        alreadyHave = true;
                        break;
                    }

                //If already exists, cancel
                if (alreadyHave == true)
                    continue;

                //Add this new entrie on this divider
                SpawnData spawnData = new SpawnData();
                spawnData.type = type;
                spawnData.id = creatureId;
                spawnData.weight = weight;
                spawnData.minCount = countMin;
                spawnData.maxCount = countMax;
                spawnDictionary[currentKey].Add(spawnData);
                biomesWhereAdded.Add(currentKey);
            }

            //Return the result
            return biomesWhereAdded.ToArray();
        }

        public string[] AddEntrieToAllDividersWhereHaveCreatureId(string type, string creatureId, string weight, string countMin, string countMax, string whereHaveCreatureId)
        {
            //Prepare the list of biomes that the new entrie was added
            List<string> biomesWhereAdded = new List<string>();

            //Process all dividers
            foreach (var item in spawnDictionary)
            {
                //Get current key
                string currentKey = item.Key;

                //Check if this divider already have the entrie inserted
                bool alreadyHave = false;
                foreach (SpawnData currentData in item.Value)
                    if (currentData.id == creatureId)
                    {
                        alreadyHave = true;
                        break;
                    }

                //If already exists, cancel
                if (alreadyHave == true)
                    continue;

                //Check if this divider have the required entrie
                bool alreadyHaveRequiredEntrie = false;
                foreach (SpawnData currentData in item.Value)
                    if (currentData.id == whereHaveCreatureId)
                    {
                        alreadyHaveRequiredEntrie = true;
                        break;
                    }

                //If not have the required entrie, cancel
                if (alreadyHaveRequiredEntrie == false)
                    continue;

                //Add this new entrie on this divider
                SpawnData spawnData = new SpawnData();
                spawnData.type = type;
                spawnData.id = creatureId;
                spawnData.weight = weight;
                spawnData.minCount = countMin;
                spawnData.maxCount = countMax;
                spawnDictionary[currentKey].Add(spawnData);
                biomesWhereAdded.Add(currentKey);
            }

            //Return the result
            return biomesWhereAdded.ToArray();
        }

        public string[] EditEntriesOnAllDividers(string whereCreatureIdIs, string newType, string newWeight, string newCountMin, string newCountMax)
        {
            //Prepare the list of biomes that the entrie was edited
            List<string> biomesWhereEdited = new List<string>();

            //Process all dividers
            foreach (var item in spawnDictionary)
            {
                //Get current key
                string currentKey = item.Key;

                //Get the id of the entrie to be edited
                int idToBeEdited = -1;
                for (int i = 0; i < spawnDictionary[currentKey].Count; i ++)
                    if (spawnDictionary[currentKey][i].id == whereCreatureIdIs)
                    {
                        idToBeEdited = i;
                        break;
                    }

                //If not found a entrie, cancel
                if (idToBeEdited == -1)
                    continue;

                //Edit this entrie
                spawnDictionary[currentKey][idToBeEdited].type = newType;
                spawnDictionary[currentKey][idToBeEdited].weight = newWeight;
                spawnDictionary[currentKey][idToBeEdited].minCount = newCountMin;
                spawnDictionary[currentKey][idToBeEdited].maxCount = newCountMax;
                biomesWhereEdited.Add(currentKey);
            }

            //Return the result
            return biomesWhereEdited.ToArray();
        }

        public string[] RemoveEntriesOnAllDividers(string whereCreatureIdIs)
        {
            //Prepare the list of biomes that the entrie was removed
            List<string> biomesWhereRemoved = new List<string>();

            //Process all dividers
            foreach (var item in spawnDictionary)
            {
                //Get current key
                string currentKey = item.Key;

                //Get the id of the entrie to be removed
                int idToBeRemoved = -1;
                for (int i = 0; i < spawnDictionary[currentKey].Count; i++)
                    if (spawnDictionary[currentKey][i].id == whereCreatureIdIs)
                    {
                        idToBeRemoved = i;
                        break;
                    }

                //If not found a entrie, cancel
                if (idToBeRemoved == -1)
                    continue;

                //Remove this entrie
                spawnDictionary[currentKey].RemoveAt(idToBeRemoved);
                biomesWhereRemoved.Add(currentKey);
            }

            //Return the result
            return biomesWhereRemoved.ToArray();
        }

        public string[] SearchEntriesOnAllDividers(string whereCreatureIdIs)
        {
            //Prepare the list of biomes that the entrie was found
            List<string> biomesWhereFound = new List<string>();

            //Process all dividers
            foreach (var item in spawnDictionary)
            {
                //Get current key
                string currentKey = item.Key;

                //Check if the entrie exists in this divider
                foreach (SpawnData spawnItem in spawnDictionary[currentKey])
                    if (spawnItem.id == whereCreatureIdIs)
                    {
                        biomesWhereFound.Add(currentKey);
                        continue;
                    }
            }

            //Return the result
            return biomesWhereFound.ToArray();
        }

        public void SaveFileChanges()
        {
            //Prepare the file lines
            List<string> fileToSaveLines = new List<string>();
            int lineCount = 1;

            //Add the comment lines
            foreach (string commentLine in commentLines)
                fileToSaveLines.Add(commentLine);

            //Process all data of spawn dictionary
            foreach (var item in spawnDictionary)
            {
                //Get current key
                string currentKey = item.Key;
                
                //Process all values
                foreach (SpawnData currentData in item.Value)
                {
                    //Get the name and biome id
                    string biomeName = currentKey.Split("/")[0];
                    string biomeId = currentKey.Split("/")[1];

                    //Add the line in file to save
                    fileToSaveLines.Add((lineCount + ", " + biomeName + ", " + biomeId + ", " + currentData.type + ", " + currentData.id + ", " + currentData.weight + ", " + currentData.minCount + ", " + currentData.maxCount));

                    //Increase the line count
                    lineCount += 1;
                }
            }

            //Save changes to file
            File.WriteAllLines(filePath, fileToSaveLines.ToArray());
        }
    }
}
