﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SBUEditor.Scripts
{
    /*
     * This is the script responsible by interpretation of "StructMobWeight.csv" file
    */

    class StructMobWeight
    {
        //Private classes
        public class SpawnData
        {
            //This class holds data of spawn

            //Public variables
            public string type = "";
            public string id = "";
            public string weight = "";
            public string minCount = "";
            public string maxCount = "";
        }
    
        //Private variables
        private string filePath = "";
        private List<string> commentLines = new List<string>();
        private Dictionary<string, List<SpawnData>> spawnDictionary = new Dictionary<string, List<SpawnData>>();

        //Core methods

        public StructMobWeight(string filePath)
        {
            //Save the data
            this.filePath = filePath;

            //Load the file
            string[] fileLines = File.ReadAllLines(filePath);

            //Process each line of file
            foreach (string line in fileLines)
            {
                //If is a comment line, skip it
                if (line[0] == '*')
                {
                    commentLines.Add(line);
                    continue;
                }

                //Divide the line
                string[] lineExploded = line.Split(", ");
                string structureName = lineExploded[1];
                string creatureType = lineExploded[2];
                string creatureId = lineExploded[3];
                string creatureWeight = lineExploded[4];
                string creatureMinCount = lineExploded[5];
                string creatureMaxCount = lineExploded[6];

                //Add the key to dictionary, if not exists
                if (spawnDictionary.ContainsKey(structureName) == false)
                    spawnDictionary.Add(structureName, new List<SpawnData>());
                //If this is a header data, skip
                if (creatureType == "HEADING")
                    continue;
                //Continue adding this spawn in the dictionary
                SpawnData spawnData = new SpawnData();
                spawnData.type = creatureType;
                spawnData.id = creatureId;
                spawnData.weight = creatureWeight;
                spawnData.minCount = creatureMinCount;
                spawnData.maxCount = creatureMaxCount;
                spawnDictionary[structureName].Add(spawnData);
            }
        }

        public ref Dictionary<string, List<SpawnData>> GetSpawnDictionaryRef()
        {
            //Return reference for spawn dictionary
            return ref spawnDictionary;
        }

        public bool AddEntrieOnDividerKey(string dividerKey, string type, string creatureId, string weight, string countMin, string countMax)
        {
            //Prepare the result
            bool added = false;

            //Check if the entrie already exists in the divider key
            bool alreadyExists = false;
            foreach (SpawnData data in spawnDictionary[dividerKey])
                if (data.id == creatureId)
                    alreadyExists = true;

            //If already exists, cancel
            if (alreadyExists == true)
                return added;

            //Add this new entrie on the divider
            SpawnData spawnData = new SpawnData();
            spawnData.type = type;
            spawnData.id = creatureId;
            spawnData.weight = weight;
            spawnData.minCount = countMin;
            spawnData.maxCount = countMax;
            spawnDictionary[dividerKey].Add(spawnData);
            added = true;

            //Return the result
            return added;
        }

        public void EditEntrieOnDividerKey(string dividerKey, string whereCreatureIdIs, string newType, string newWeight, string newCountMin, string newCountMax)
        {
            //Find the id of the entrie to edit
            int idToEdit = -1;
            for (int i = 0; i < spawnDictionary[dividerKey].Count; i++)
                if (spawnDictionary[dividerKey][i].id == whereCreatureIdIs)
                {
                    idToEdit = i;
                    break;
                }

            //Edit the entrie, if found
            if (idToEdit != -1)
            {
                spawnDictionary[dividerKey][idToEdit].type = newType;
                spawnDictionary[dividerKey][idToEdit].weight = newWeight;
                spawnDictionary[dividerKey][idToEdit].minCount = newCountMin;
                spawnDictionary[dividerKey][idToEdit].maxCount = newCountMax;
            }
        }

        public void RemoveEntriesOfDividerKey(string dividerKey, string[] creatureIdsToRemove)
        {
            //Re-create the entrie in list
            List<string> creatureIdsToRemoveList = new List<string>();
            foreach (string id in creatureIdsToRemove)
                creatureIdsToRemoveList.Add(id);

            //Remove all entries of list
            while (creatureIdsToRemoveList.Count > 0)
            {
                //Get the first id of list
                string currentIdToRemove = creatureIdsToRemoveList[0];

                //Get the id of the entrie to remove
                int idToRemove = -1;
                for (int i = 0; i < spawnDictionary[dividerKey].Count; i++)
                    if (spawnDictionary[dividerKey][i].id == currentIdToRemove)
                    {
                        idToRemove = i;
                        break;
                    }

                //If was found some element, remove it
                if (idToRemove != -1)
                    spawnDictionary[dividerKey].RemoveAt(idToRemove);

                //Remove this first element
                creatureIdsToRemoveList.RemoveAt(0);
            }
        }

        public string[] SearchEntriesOnAllDividers(string whereCreatureIdIs)
        {
            //Prepare the list of structures that the entrie was found
            List<string> structuresWhereFound = new List<string>();

            //Process all dividers
            foreach (var item in spawnDictionary)
            {
                //Get current key
                string currentKey = item.Key;

                //Check if the entrie exists in this divider
                foreach (SpawnData spawnItem in spawnDictionary[currentKey])
                    if (spawnItem.id == whereCreatureIdIs)
                    {
                        structuresWhereFound.Add(currentKey);
                        continue;
                    }
            }

            //Return the result
            return structuresWhereFound.ToArray();
        }

        public void SaveFileChanges()
        {
            //Prepare the file lines
            List<string> fileToSaveLines = new List<string>();
            int lineCount = 1;

            //Add the comment lines
            foreach (string commentLine in commentLines)
                fileToSaveLines.Add(commentLine);

            //Process all data of spawn dictionary
            foreach (var item in spawnDictionary)
            {
                //Get current key
                string currentKey = item.Key;

                //Add the header of this structure
                fileToSaveLines.Add((lineCount + ", " + currentKey + ", " + "HEADING" + ", " + "header:ignore" + ", " + "0" + ", " + "0" + ", " + "0"));

                //Increase the line count
                lineCount += 1;

                //Process all values
                foreach (SpawnData currentData in item.Value)
                {
                    //Add the line in file to save
                    fileToSaveLines.Add((lineCount + ", " + currentKey + ", " + currentData.type + ", " + currentData.id + ", " + currentData.weight + ", " + currentData.minCount + ", " + currentData.maxCount));

                    //Increase the line count
                    lineCount += 1;
                }
            }

            //Save changes to file
            File.WriteAllLines(filePath, fileToSaveLines.ToArray());
        }
    }
}
