﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static SBUEditor.WindowEditEntrie.ClassDelegates;

namespace SBUEditor
{
    /*
     * This is the script responsible by the window of entrie remove
    */

    public partial class WindowRemoveEntrie : Window
    {
        //Private enums
        public enum EditionType
        {
            ToCurrentDivider,
            ToAllDividers
        }

        //Classes of script
        public class ClassDelegates
        {
            public delegate void OnRemove(string whereCreatureIdIs);
        }

        //Private variables
        private EditionType edditionType;
        private event ClassDelegates.OnRemove onRemove;

        //Core methods

        public WindowRemoveEntrie(EditionType type, string creatureIdToRemove, ClassDelegates.OnRemove onRemove)
        {
            //Initialize the Window
            InitializeComponent();

            //Store variables
            this.edditionType = type;
            this.idTxt.Text = creatureIdToRemove;
            this.onRemove = onRemove;

            //Prepare the UI
            PrepareTheUI();
        }
    
        private void PrepareTheUI()
        {
            //On click on remove button
            removeBtn.Click += (s, e) =>
            {
                //If creature id is not valid, cancel
                if (idTxt.Text == "" || idTxt.Text.Contains(":") == false)
                {
                    MessageBox.Show("Invalid Creature ID!", "Error", MessageBoxButton.OK);
                    return;
                }

                //Send the callback
                if (this.onRemove != null)
                    this.onRemove(idTxt.Text);

                //Close this window
                this.Close();
            };
        }
    }
}
