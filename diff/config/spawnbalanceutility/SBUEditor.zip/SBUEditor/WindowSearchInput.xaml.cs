﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static SBUEditor.WindowRemoveEntrie.ClassDelegates;

namespace SBUEditor
{
    /*
     * This is the script responsible by the window of entrie search
    */

    public partial class WindowSearchInput : Window
    {
        //Classes of script
        public class ClassDelegates
        {
            public delegate void OnSearch(string whereCreatureIdIs);
        }

        //Private variables
        private event ClassDelegates.OnSearch onSearch;

        //Core methods

        public WindowSearchInput(string creatureIdToSearch, ClassDelegates.OnSearch onSearch)
        {
            //Initialize the Window
            InitializeComponent();

            //Store variables
            this.idTxt.Text = creatureIdToSearch;
            this.onSearch = onSearch;

            //Prepare the UI
            PrepareTheUI();
        }

        private void PrepareTheUI()
        {
            //On click on search button
            searchBtn.Click += (s, e) =>
            {
                //If creature id is not valid, cancel
                if (idTxt.Text == "" || idTxt.Text.Contains(":") == false)
                {
                    MessageBox.Show("Invalid Creature ID!", "Error", MessageBoxButton.OK);
                    return;
                }

                //Send the callback
                if (this.onSearch != null)
                    this.onSearch(idTxt.Text);

                //Close this window
                this.Close();
            };
        }
    }
}
