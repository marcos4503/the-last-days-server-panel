﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SBUEditor.Controls
{
    /*
     * This script is resposible by the work of the "Spawn Item" that represents each
     * Entrie resource found in file...
    */

    public partial class SpawnItem : UserControl
    {
        //Classes of script
        public class ClassDelegates
        {
            public delegate void OnChangeSelection();
        }

        //Private variables
        private WindowEdit instantiatedBy = null;
        private string ownerKey = "";
        private bool isSelected = false;
        private event ClassDelegates.OnChangeSelection onChangeSelection;

        //Core methods

        public SpawnItem(WindowEdit instantiatedBy)
        {
            //Initialize the component
            InitializeComponent();

            //Inform that is the DataConext of this User Control
            this.DataContext = this;

            //Store all data
            this.instantiatedBy = instantiatedBy;
        }
    
        //Public methods

        public void SetOwnerKey(string ownerKey)
        {
            //Store the owner key
            this.ownerKey = ownerKey;
        }

        public void SetType(string type)
        {
            //Render the type
            if (type == "MONSTER")
            {
                typeIcon.Background = new SolidColorBrush(Color.FromArgb(255, 202, 0, 0));
                typeIcon.BorderBrush = new SolidColorBrush(Color.FromArgb(255, 127, 0, 0));
            }
            if (type == "CREATURE")
            {
                typeIcon.Background = new SolidColorBrush(Color.FromArgb(255, 214, 226, 0));
                typeIcon.BorderBrush = new SolidColorBrush(Color.FromArgb(255, 170, 179, 0));
            }
            if (type == "AMBIENT")
            {
                typeIcon.Background = new SolidColorBrush(Color.FromArgb(255, 105, 105, 105));
                typeIcon.BorderBrush = new SolidColorBrush(Color.FromArgb(255, 60, 60, 60));
            }
            if (type == "UNDERGROUND_WATER_CREATURE")
            {
                typeIcon.Background = new SolidColorBrush(Color.FromArgb(255, 0, 36, 148));
                typeIcon.BorderBrush = new SolidColorBrush(Color.FromArgb(255, 0, 21, 86));
            }
            if (type == "WATER_CREATURE")
            {
                typeIcon.Background = new SolidColorBrush(Color.FromArgb(255, 0, 140, 230));
                typeIcon.BorderBrush = new SolidColorBrush(Color.FromArgb(255, 0, 120, 197));
            }
            if (type == "WATER_AMBIENT")
            {
                typeIcon.Background = new SolidColorBrush(Color.FromArgb(255, 0, 226, 210));
                typeIcon.BorderBrush = new SolidColorBrush(Color.FromArgb(255, 0, 173, 161));
            }
            if (type == "AXOLOTLS")
            {
                typeIcon.Background = new SolidColorBrush(Color.FromArgb(255, 136, 0, 255));
                typeIcon.BorderBrush = new SolidColorBrush(Color.FromArgb(255, 99, 0, 185));
            }

            //Show the name
            StringBuilder typeBuilder = new StringBuilder();
            string[] words = type.Split("_");
            foreach(string word in words)
            {
                string toLower = word.ToLower();
                string firstLetter = toLower[0].ToString();
                string rest = toLower.Remove(0, 1);
                typeBuilder.Append((" " + firstLetter.ToUpper() + rest));
            }
            typeTxt.Text = typeBuilder.ToString().Remove(0, 1);
        }
    
        public void SetID(string id)
        {
            //Show the ID
            idTxt.Text = id;
        }

        public void SetWeight(string weight)
        {
            //Show the weight
            weightTxt.Text = weight;
        }
    
        public void SetCountMin(string countMin)
        {
            //Show the count min
            countMinTxt.Text = countMin;
        }

        public void SetCountMax(string countMax)
        {
            //Show the count max
            countMaxTxt.Text = countMax;
        }

        public void RegisterOnChangeSelectionCallback(ClassDelegates.OnChangeSelection onChangeSelection)
        {
            //Register the event
            this.onChangeSelection = onChangeSelection;
        }

        public void Prepare()
        {
            //Prepare the color highlight
            bg.MouseEnter += (s, e) =>
            {
                bg.Background = new SolidColorBrush(Color.FromArgb(255, 208, 241, 255));
            };
            bg.MouseLeave += (s, e) =>
            {
                bg.Background = new SolidColorBrush(Color.FromArgb(255, 255, 255, 255));
            };

            //Prepare the click
            bg.MouseDown += (s, e) =>
            {
                //Change selection
                check.IsChecked = !check.IsChecked;

                //Send callback
                if (this.onChangeSelection != null)
                    this.onChangeSelection();
            };
        }
    }
}
