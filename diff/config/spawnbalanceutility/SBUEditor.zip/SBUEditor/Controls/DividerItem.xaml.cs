﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace SBUEditor.Controls
{
    /*
     * This script is resposible by the work of the "Divider Item" that represents each
     * Divider resource found in file...
    */

    public partial class DividerItem : UserControl
    {
        //Public enums
        public enum DividerState
        {
            Normal,
            Hidden
        }

        //Classes of script
        public class ClassDelegates
        {
            public delegate void OnClick(string dividerKey);
        }

        //Private variables
        private WindowEdit instantiatedBy = null;
        private string dividerKey = "";
        private event ClassDelegates.OnClick onClick;

        //Core methods

        public DividerItem(WindowEdit instantiatedBy)
        {
            //Initialize the component
            InitializeComponent();

            //Inform that is the DataConext of this User Control
            this.DataContext = this;

            //Store all data
            this.instantiatedBy = instantiatedBy;
        }

        //Public methods

        public void SetDividerKey(string dividerKey)
        {
            //Store the value
            this.dividerKey = dividerKey;

            //If have a description..
            if (dividerKey.Contains("/") == true)
            {
                //Divide string
                string[] keyExploded = dividerKey.Split("/");

                //Set the value
                itemName.Text = keyExploded[1];
                itemDescription.Text = keyExploded[0];
            }
            //If don't have a description
            if (dividerKey.Contains("/") == false)
            {
                //Fix value
                int maxChars = 40;
                string fixedString = "";
                if (dividerKey.Length > maxChars)
                    fixedString = (dividerKey.Substring(0, maxChars) + "...");
                if (dividerKey.Length <= maxChars)
                    fixedString = dividerKey;

                //Set the value
                itemName.Text = fixedString;
                itemDescription.Text = "";
            }
        }

        public void RegisterOnClickCallback(ClassDelegates.OnClick onClick)
        {
            //Register the event
            this.onClick = onClick;
        }

        public void Prepare()
        {
            //Prepare the color highlight
            bg.MouseEnter += (s, e) =>
            {
                bg.Background = new SolidColorBrush(Color.FromArgb(255, 208, 241, 255));
            };
            bg.MouseLeave += (s, e) =>
            {
                bg.Background = new SolidColorBrush(Color.FromArgb(255, 255, 255, 255));
            };

            //Prepare the click
            bg.MouseDown += (s, e) => 
            {
                //Run the click callback
                if (this.onClick != null)
                    this.onClick(this.dividerKey);
            };
        }

        //Auxiliar methods

        public void SetState(DividerState newState)
        {
            //Change the state
            if (newState == DividerState.Normal)
                rootGrid.Opacity = 1.0f;
            if (newState == DividerState.Hidden)
                rootGrid.Opacity = 0.2f;
        }
    
        public void SetEnabled(bool enabled)
        {
            //If is enabled..
            if (enabled == true)
                bg.BorderBrush = new SolidColorBrush(Color.FromArgb(255, 0, 167, 255));
            //If is disabled...
            if (enabled == false)
                bg.BorderBrush = null;
        }
    }
}
