﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static SBUEditor.WindowAddEntrie;

namespace SBUEditor
{
    /*
     * This is the script responsible by the window of entrie add where have a spawn
    */

    public partial class WindowAddEntrieWhere : Window
    {
        //Classes of script
        public class ClassDelegates
        {
            public delegate void OnAdd(string type, string creatureId, string weight, string countMin, string countMax, string whereHaveCreatureId);
        }

        //Private variables
        private event ClassDelegates.OnAdd onAdd;

        //Core methods

        public WindowAddEntrieWhere(ClassDelegates.OnAdd onAdd)
        {
            //Initialize the Window
            InitializeComponent();

            //Prepare the UI
            PrepareTheUI();

            //Store variables
            this.onAdd = onAdd;
        }

        private void PrepareTheUI()
        {
            //On click on add button
            addBtn.Click += (s, e) =>
            {
                //If creature id is not valid, cancel
                if (idTxt.Text == "" || idTxt.Text.Contains(":") == false)
                {
                    MessageBox.Show("Invalid Creature ID!", "Error", MessageBoxButton.OK);
                    return;
                }
                //If spawn weight is not valid, cancel
                int weight = 0;
                int.TryParse(weightTxt.Text, out weight);
                if (weight < 1 || weight > 1000)
                {
                    MessageBox.Show("Invalid Weight, smaller than 1 or higher than 1000!", "Error", MessageBoxButton.OK);
                    return;
                }
                //If count is not valid, cancel
                int minCount = 0;
                int.TryParse(countMinTxt.Text, out minCount);
                int maxCount = 0;
                int.TryParse(countMaxTxt.Text, out maxCount);
                if (minCount < 1 || maxCount < 1)
                {
                    MessageBox.Show("Invalid min/max counts!", "Error", MessageBoxButton.OK);
                    return;
                }

                //Get the spawn type
                string type = "";
                if (typeCb.SelectedIndex == 0)
                    type = "MONSTER";
                if (typeCb.SelectedIndex == 1)
                    type = "CREATURE";
                if (typeCb.SelectedIndex == 2)
                    type = "AMBIENT";
                if (typeCb.SelectedIndex == 3)
                    type = "UNDERGROUND_WATER_CREATURE";
                if (typeCb.SelectedIndex == 4)
                    type = "WATER_CREATURE";
                if (typeCb.SelectedIndex == 5)
                    type = "WATER_AMBIENT";
                if (typeCb.SelectedIndex == 6)
                    type = "AXOLOTLS";

                //Send the callback
                if (this.onAdd != null)
                    this.onAdd(type, idTxt.Text, weightTxt.Text, countMinTxt.Text, countMaxTxt.Text, whereTxt.Text);

                //Close this window
                this.Close();
            };
        }
    }
}
