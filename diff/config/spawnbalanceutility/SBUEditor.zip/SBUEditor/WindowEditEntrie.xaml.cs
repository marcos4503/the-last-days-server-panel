﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static SBUEditor.WindowAddEntrie;
using static SBUEditor.WindowAddEntrie.ClassDelegates;

namespace SBUEditor
{
    /*
     * This is the script responsible by the window of entrie edit
    */

    public partial class WindowEditEntrie : Window
    {
        //Private enums
        public enum EditionType
        {
            ToCurrentDivider,
            ToAllDividers
        }

        //Classes of script
        public class ClassDelegates
        {
            public delegate void OnEdit(string whereCreatureIdIs, string newType, string newWeight, string newCountMin, string newCountMax);
        }

        //Private variables
        private EditionType edditionType;
        private event ClassDelegates.OnEdit onEdit;

        //Core methods

        public WindowEditEntrie(EditionType type, string creatureIdToEdit, string cType, string weight, string countMin, string countMax, ClassDelegates.OnEdit onEdit)
        {
            //Initialize the Window
            InitializeComponent();

            //Store variables
            this.edditionType = type;
            this.idTxt.Text = creatureIdToEdit;
            if (cType == "Monster")
                typeCb.SelectedIndex = 0;
            if (cType == "Creature")
                typeCb.SelectedIndex = 1;
            if (cType == "Ambient")
                typeCb.SelectedIndex = 2;
            if (cType == "Underground Water Creature")
                typeCb.SelectedIndex = 3;
            if (cType == "Water Creature")
                typeCb.SelectedIndex = 4;
            if (cType == "Water Ambient")
                typeCb.SelectedIndex = 5;
            if (cType == "Axolotls")
                typeCb.SelectedIndex = 6;
            weightTxt.Text = weight;
            countMinTxt.Text = countMin;
            countMaxTxt.Text = countMax;
            this.onEdit = onEdit;

            //Prepare the UI
            PrepareTheUI();
        }

        private void PrepareTheUI()
        {
            //If the eddition type is to current divider...
            if (edditionType == EditionType.ToCurrentDivider)
            {
                this.Title = "Edit Spawn Entrie";
                idTxt.IsEnabled = false;
            }
            //If the eddition type is to all dividers...
            if (edditionType == EditionType.ToAllDividers)
            {
                this.Title = "Edit All Spawn Entries";
                idTxt.IsEnabled = true;
            }

            //On click on add button
            editBtn.Click += (s, e) =>
            {
                //If creature id is not valid, cancel
                if (idTxt.Text == "" || idTxt.Text.Contains(":") == false)
                {
                    MessageBox.Show("Invalid Creature ID!", "Error", MessageBoxButton.OK);
                    return;
                }
                //If spawn weight is not valid, cancel
                int weight = 0;
                int.TryParse(weightTxt.Text, out weight);
                if (weight < 1 || weight > 1000)
                {
                    MessageBox.Show("Invalid Weight, smaller than 1 or higher than 1000!", "Error", MessageBoxButton.OK);
                    return;
                }
                //If count is not valid, cancel
                int minCount = 0;
                int.TryParse(countMinTxt.Text, out minCount);
                int maxCount = 0;
                int.TryParse(countMaxTxt.Text, out maxCount);
                if (minCount < 1 || maxCount < 1)
                {
                    MessageBox.Show("Invalid min/max counts!", "Error", MessageBoxButton.OK);
                    return;
                }

                //Get the spawn type
                string type = "";
                if (typeCb.SelectedIndex == 0)
                    type = "MONSTER";
                if (typeCb.SelectedIndex == 1)
                    type = "CREATURE";
                if (typeCb.SelectedIndex == 2)
                    type = "AMBIENT";
                if (typeCb.SelectedIndex == 3)
                    type = "UNDERGROUND_WATER_CREATURE";
                if (typeCb.SelectedIndex == 4)
                    type = "WATER_CREATURE";
                if (typeCb.SelectedIndex == 5)
                    type = "WATER_AMBIENT";
                if (typeCb.SelectedIndex == 6)
                    type = "AXOLOTLS";

                //Send the callback
                if (this.onEdit != null)
                    this.onEdit(idTxt.Text, type, weightTxt.Text, countMinTxt.Text, countMaxTxt.Text);

                //Close this window
                this.Close();
            };
        }
    }
}
