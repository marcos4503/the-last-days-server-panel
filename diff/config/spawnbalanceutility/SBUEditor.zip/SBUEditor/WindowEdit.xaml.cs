﻿using SBUEditor.Controls;
using SBUEditor.Scripts;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SBUEditor
{
    /*
     * This is the script responsible by the main window of the editor
    */

    public partial class WindowEdit : Window
    {
        //Public enums
        public enum FileType
        {
            Unknown,
            BiomesSpawns,
            StructuresSpawns
        }

        //Private variables
        private string programDirPath = "";
        private FileType editingFileType = FileType.Unknown;
        private List<DividerItem> instantiatedDividerItems = new List<DividerItem>();
        private List<SpawnItem> instantiatedSpawnItems = new List<SpawnItem>();

        //Core methods

        public WindowEdit(FileType fileTypeToEdit)
        {
            //Get current dir of program
            programDirPath = AppDomain.CurrentDomain.BaseDirectory;
            programDirPath = programDirPath.Remove((programDirPath.Length - 1), 1);  //<- Remove the last "\" character

            //Get the file type to edit
            editingFileType = fileTypeToEdit;

            //Initialize the Window
            InitializeComponent();

            //Prepare the UI
            PrepareTheUI();
        }

        private void PrepareTheUI()
        {
            //If the file type to edit is "BiomesSpawns"...
            if (editingFileType == FileType.BiomesSpawns)
            {
                //Change the window title
                this.Title = "SBUEditor - Biomes Spawns";

                //If the file "BiomeMobWeight.csv" don't exists, create it using "BiomeMobWeight.rpt" file...
                if (File.Exists((programDirPath + "/BiomeMobWeight.csv")) == false)
                    File.Copy((programDirPath + "/BiomeMobWeight.rpt"), (programDirPath + "/BiomeMobWeight.csv"));

                //Add description to buttons
                saveFileBtn.ToolTip = "Save Changes to \"BiomeMobWeight.csv\"";
                addToAllBtn.ToolTip = "Add Spawn In All Biomes (Without Duplicates)...";
                addToAllWhereBtn.ToolTip = "Add Spawn In All Biomes, Where Spawns a Creature (Without Duplicates)...";
                editToAllBtn.ToolTip = "Edit Spawn Of All Biomes (Where Find)...";
                removeOfAllBtn.ToolTip = "Remove Spawn Of All Biomes (Where Exists)...";
                clearFileBtn.ToolTip = "Delete \"BiomeMobWeight.csv\"";
                searchInAllBtn.ToolTip = "Search Spawn In All Biomes...";

                //Prepare the search place holder
                dividerSearchPh.Text = "Type here to search by Biomes...";

                //Initialize the edition for Biomes Spawns
                BiomeSpawns_Initialize();
            }
            //If the file type to edit is "StructuresSpawns"...
            if (editingFileType == FileType.StructuresSpawns)
            {
                //Change the window title
                this.Title = "SBUEditor - Structures Spawns";

                //If the file "BiomeMobWeight.csv" don't exists, create it using "BiomeMobWeight.rpt" file...
                if (File.Exists((programDirPath + "/StructMobWeight.csv")) == false)
                    File.Copy((programDirPath + "/StructMobWeight.rpt"), (programDirPath + "/StructMobWeight.csv"));

                //Add description to buttons
                saveFileBtn.ToolTip = "Save Changes to \"StructMobWeight.csv\"";
                addToAllBtn.Visibility = Visibility.Collapsed;
                addToAllWhereBtn.Visibility = Visibility.Collapsed;
                editToAllBtn.Visibility = Visibility.Collapsed;
                removeOfAllBtn.Visibility = Visibility.Collapsed;
                clearFileBtn.ToolTip = "Delete \"StructMobWeight.csv\"";
                searchInAllBtn.ToolTip = "Search Spawn In All Structures...";

                //Prepare the search place holder
                dividerSearchPh.Text = "Type here to search by Structures...";

                //Initialize the edition for Structures Spawns
                StructureSpawns_Initialize();
            }

            //Prepare the search box
            dividerSearch.TextChanged += (s, e) => {
                //Show or hide the search place holder
                if (dividerSearch.Text == "")
                    dividerSearchPh.Visibility = Visibility.Visible;
                if (dividerSearch.Text != "")
                    dividerSearchPh.Visibility = Visibility.Collapsed;

                //Process the seach
                ProcessSearch(dividerSearch.Text);
            };
        }

        private void ProcessSearch(string searchExpression)
        {
            //If the search expression is not empty, hide all that not matches with searched term
            if (searchExpression != "")
                foreach (DividerItem item in instantiatedDividerItems)
                {
                    //If this match with the searched term...
                    if (item.itemName.Text.Contains(searchExpression) == true || item.itemDescription.Text.Contains(searchExpression) == true)
                        item.SetState(DividerItem.DividerState.Normal);

                    //If this not match with the searched term...
                    if (item.itemName.Text.Contains(searchExpression) == false && item.itemDescription.Text.Contains(searchExpression) == false)
                        item.SetState(DividerItem.DividerState.Hidden);
                }

            //If the search expression is empty, show all as normal
            if (searchExpression == "")
                foreach (DividerItem item in instantiatedDividerItems)
                    item.SetState(DividerItem.DividerState.Normal);
        }

        private void ProcessSelection()
        {
            //Get selection count
            int selectionCount = 0;
            foreach (SpawnItem item in instantiatedSpawnItems)
                if (item.check.IsChecked == true)
                    selectionCount += 1;

            //If is selected just one
            if (selectionCount == 1)
            {
                editBtn.Opacity = 0.75f;
                editBtn.IsHitTestVisible = true;
            }
            //If is selected zero or more than one
            if (selectionCount != 1)
            {
                editBtn.Opacity = 0.25f;
                editBtn.IsHitTestVisible = false;
            }

            //If selected more than zero
            if (selectionCount > 0)
            {
                removeBtn.Opacity = 0.75f;
                removeBtn.IsHitTestVisible = true;
            }
            //If selected zero
            if (selectionCount == 0)
            {
                removeBtn.Opacity = 0.25f;
                removeBtn.IsHitTestVisible = false;
            }

            //If is selected more than zero
            if (selectionCount > 0)
            {
                selectionCountTxt.Text = (selectionCount + " selected Entries");
                selectionCountTxt.Visibility = Visibility.Visible;
            }
            //If is selected zero
            if (selectionCount == 0)
                selectionCountTxt.Visibility = Visibility.Collapsed;
        }

        //Auxiliar methods

        private void SetInteractionBlockerEnabled(bool enabled)
        {
            //Shows or hide the interaction blocker
            if (enabled == true)
                interfaceBlocker.Visibility = Visibility.Visible;
            if (enabled == false)
                interfaceBlocker.Visibility = Visibility.Collapsed;
        }

        //------------------ Biome Spawns ------------------//

        //Private variables
        private BiomeMobWeight biomeMobWeight = null;
        private string biomeSpawns_currentSelectedDividerKey = "";

        //Core methods

        private void BiomeSpawns_Initialize()
        {
            //Load the "BiomeMobWeight.csv" file
            biomeMobWeight = new BiomeMobWeight((programDirPath + "/BiomeMobWeight.csv"));

            //Prepare the divider add button
            addBtn.Click += (s, e) =>
            {
                //Open the add entrie window
                SetInteractionBlockerEnabled(true);
                WindowAddEntrie windowAddEntrie = new WindowAddEntrie(WindowAddEntrie.AdditionType.ToCurrentDivider, (type, creatureId, weight, countMin, countMax) => {
                    BiomeSpawns_AddToCurrentDivider(type, creatureId, weight, countMin, countMax);
                });
                windowAddEntrie.Closed += (s, e) => { SetInteractionBlockerEnabled(false); };
                windowAddEntrie.Show();
            };

            //Prepare the divider edit button
            editBtn.Click += (s, e) =>
            {
                //Find the entrie id and current data to edit
                string entrieIdToEdit = "";
                string entrieType = "";
                string entrieWeight = "";
                string entrieCountMin = "";
                string entrieCountMax = "";
                foreach (SpawnItem item in instantiatedSpawnItems)
                    if (item.check.IsChecked == true)
                    {
                        entrieIdToEdit = item.idTxt.Text;
                        entrieType = item.typeTxt.Text;
                        entrieWeight = item.weightTxt.Text;
                        entrieCountMin = item.countMinTxt.Text;
                        entrieCountMax = item.countMaxTxt.Text;
                        break;
                    }

                //Open the edit entrie window
                SetInteractionBlockerEnabled(true);
                WindowEditEntrie windowEditEntrie = new WindowEditEntrie(WindowEditEntrie.EditionType.ToCurrentDivider, entrieIdToEdit, entrieType, entrieWeight, entrieCountMin, entrieCountMax,
                    (whereCreatureIdIs, newType, newWeight, newCountMin, newCountMax) => {
                        BiomeSpawns_EditFromCurrentDivider(whereCreatureIdIs, newType, newWeight, newCountMin, newCountMax);
                    });
                windowEditEntrie.Closed += (s, e) => { SetInteractionBlockerEnabled(false); };
                windowEditEntrie.Show();
            };

            //Prepare the remover button
            removeBtn.Click += (s, e) =>
            {
                //Confirm the remotion
                SetInteractionBlockerEnabled(true);
                MessageBoxResult result = MessageBox.Show("Are you sure you want to remove the selected Entries?", "Remove Entries", MessageBoxButton.YesNo);
                SetInteractionBlockerEnabled(false);
                if (result == MessageBoxResult.Yes)
                    BiomeSpawns_RemoveFromCurrentDivider();
            };

            //Prepare the save button
            saveFileBtn.Click += (s, e) =>
            {
                //Save the changes to file
                BiomeSpawns_SaveChangesToFile();
            };

            //Prepare the add entries on all dividers button
            addToAllBtn.Click += (s, e) =>
            {
                //Open the add entrie window
                SetInteractionBlockerEnabled(true);
                WindowAddEntrie windowAddEntrie = new WindowAddEntrie(WindowAddEntrie.AdditionType.ToAllDividers, (type, creatureId, weight, countMin, countMax) => {
                    BiomeSpawns_AddToAllDividers(type, creatureId, weight, countMin, countMax);
                });
                windowAddEntrie.Closed += (s, e) => { SetInteractionBlockerEnabled(false); };
                windowAddEntrie.Show();
            };

            //Prepare the add entries on all dividers where have creature entrie button
            addToAllWhereBtn.Click += (s, e) =>
            {
                //Open the add entrie window
                SetInteractionBlockerEnabled(true);
                WindowAddEntrieWhere windowAddEntrie = new WindowAddEntrieWhere((type, creatureId, weight, countMin, countMax, whereHaveCreatureId) => {
                    BiomeSpawns_AddToAllDividersWhereHaveSpawnEntrie(type, creatureId, weight, countMin, countMax, whereHaveCreatureId);
                });
                windowAddEntrie.Closed += (s, e) => { SetInteractionBlockerEnabled(false); };
                windowAddEntrie.Show();
            };

            //Prepare the edit entries on all dividers button
            editToAllBtn.Click += (s, e) =>
            {
                //Open the edit entrie window
                SetInteractionBlockerEnabled(true);
                WindowEditEntrie windowEditEntrie = new WindowEditEntrie(WindowEditEntrie.EditionType.ToAllDividers, "minecraft:mob_example", "MONSTER", "5", "1", "1",
                    (whereCreatureIdIs, newType, newWeight, newCountMin, newCountMax) => {
                        BiomeSpawns_EditFromAllDividers(whereCreatureIdIs, newType, newWeight, newCountMin, newCountMax);
                    });
                windowEditEntrie.Closed += (s, e) => { SetInteractionBlockerEnabled(false); };
                windowEditEntrie.Show();
            };

            //Prepare the remove entries on all dividers button
            removeOfAllBtn.Click += (s, e) =>
            {
                //Open the remove entrie window
                SetInteractionBlockerEnabled(true);
                WindowRemoveEntrie windowRemoveEntrie = new WindowRemoveEntrie(WindowRemoveEntrie.EditionType.ToAllDividers, "minecraft:mob_example", (whereCreatureIdIs) => {
                    BiomeSpawns_RemoveFromAllDividers(whereCreatureIdIs);
                });
                windowRemoveEntrie.Closed += (s, e) => { SetInteractionBlockerEnabled(false); };
                windowRemoveEntrie.Show();
            };

            //Prepare the search on all dividers button
            searchInAllBtn.Click += (s, e) =>
            {
                //Open the remove entrie window
                SetInteractionBlockerEnabled(true);
                WindowSearchInput windowSearchInput = new WindowSearchInput("minecraft:mob_example", (whereCreatureIdIs) =>
                {
                    BiomeSpawns_SearchEntrieInAllDividers(whereCreatureIdIs);
                });
                windowSearchInput.Closed += (s, e) => { SetInteractionBlockerEnabled(false); };
                windowSearchInput.Show();
            };

            //Prepare the clear button
            clearFileBtn.Click += (s, e) =>
            {
                //Clear the file
                BiomeSpawns_ClearFile();
            };

            //Update the renderization of the entire file
            BiomeSpawns_UpdateRenderization();
        }

        private void BiomeSpawns_UpdateRenderization()
        {
            //Update dividers renderization
            BiomeSpawns_UpdateDividersRenderization();

            //Auto-select the first divider
            BiomeSpawns_UpdateEntriesRenderization(biomeMobWeight.GetSpawnDictionaryRef().Keys.First());
        }

        private void BiomeSpawns_UpdateDividersRenderization()
        {
            //Clear all previously divider rendered
            foreach (DividerItem item in instantiatedDividerItems)
                dividerList.Children.Remove(item);
            instantiatedDividerItems.Clear();

            //Render all dividers
            foreach (string item in biomeMobWeight.GetSpawnDictionaryRef().Keys)
            {
                //Draw the item on screen
                DividerItem newItem = new DividerItem(this);
                dividerList.Children.Add(newItem);
                instantiatedDividerItems.Add(newItem);

                //Configure it
                newItem.HorizontalAlignment = HorizontalAlignment.Stretch;
                newItem.VerticalAlignment = VerticalAlignment.Top;
                newItem.Width = double.NaN;
                newItem.Height = double.NaN;
                newItem.Margin = new Thickness(0, 8, 0, 0);

                //Inform the data about the divider
                newItem.SetDividerKey(item);
                newItem.RegisterOnClickCallback((key) => { 
                    //Change to render the entries of the clicked divider
                    this.BiomeSpawns_UpdateEntriesRenderization(key);

                    //Move the spawn scroll view to top
                    spawnScroll.ScrollToTop();
                });
                newItem.Prepare();
            }
        }

        private void BiomeSpawns_UpdateEntriesRenderization(string dividerKey)
        {
            //Disable all divider
            foreach (DividerItem item in instantiatedDividerItems)
                item.SetEnabled(false);
            //Enable the selected divider
            foreach (DividerItem item in instantiatedDividerItems)
                if ((item.itemDescription.Text + "/" + item.itemName.Text) == dividerKey)
                    item.SetEnabled(true);

            //Clear all previously entries rendered
            foreach (SpawnItem item in instantiatedSpawnItems)
                spawnsList.Children.Remove(item);
            instantiatedSpawnItems.Clear();

            //Render all entries
            foreach (BiomeMobWeight.SpawnData item in biomeMobWeight.GetSpawnDictionaryRef()[dividerKey])
            {
                //Draw the item on screen
                SpawnItem newItem = new SpawnItem(this);
                spawnsList.Children.Add(newItem);
                instantiatedSpawnItems.Add(newItem);

                //Configure it
                newItem.HorizontalAlignment = HorizontalAlignment.Stretch;
                newItem.VerticalAlignment = VerticalAlignment.Top;
                newItem.Width = double.NaN;
                newItem.Height = double.NaN;
                newItem.Margin = new Thickness(0, 8, 0, 0);

                //Inform the data about the divider
                newItem.SetOwnerKey(dividerKey);
                newItem.SetType(item.type);
                newItem.SetID(item.id);
                newItem.SetWeight(item.weight);
                newItem.SetCountMin(item.minCount);
                newItem.SetCountMax(item.maxCount);
                newItem.RegisterOnChangeSelectionCallback(() => { ProcessSelection(); });
                newItem.Prepare();
            }

            //Update the status bar
            statusBarTxt.Text = (instantiatedDividerItems.Count + " Biomes found. Selected \"" + dividerKey.Split("/")[1] + "\", have " + biomeMobWeight.GetSpawnDictionaryRef()[dividerKey].Count + " Spawn entries...");

            //Show or hide the empty warn
            if (biomeMobWeight.GetSpawnDictionaryRef()[dividerKey].Count == 0)
                spawnsEmptyWarn.Visibility = Visibility.Visible;
            if (biomeMobWeight.GetSpawnDictionaryRef()[dividerKey].Count > 0)
                spawnsEmptyWarn.Visibility = Visibility.Collapsed;

            //Inform the current selected divided key
            biomeSpawns_currentSelectedDividerKey = dividerKey;

            //Process current selection
            ProcessSelection();
        }

        private void BiomeSpawns_AddToCurrentDivider(string type, string creatureId, string weight, string countMin, string countMax)
        {
            //Add the new entrie
            bool added = biomeMobWeight.AddEntrieOnDividerKey(biomeSpawns_currentSelectedDividerKey, type, creatureId, weight, countMin, countMax);

            //Update the renderization
            BiomeSpawns_UpdateEntriesRenderization(biomeSpawns_currentSelectedDividerKey);

            //If not added, warn
            if (added == false)
                MessageBox.Show("New Entry not added. There is probably already an Entry with this Creature ID in this Biome.", "Not Added", MessageBoxButton.OK);
            //If added, move to end
            if (added == true)
                spawnScroll.ScrollToEnd();

            //Show dirt
            if (this.Title.Contains("*") == false)
                this.Title = (this.Title + "*");
        }

        private void BiomeSpawns_EditFromCurrentDivider(string whereCreatureIdIs, string newType, string newWeight, string newCountMin, string newCountMax)
        {
            //Edit the entrie
            biomeMobWeight.EditEntrieOnDividerKey(biomeSpawns_currentSelectedDividerKey, whereCreatureIdIs, newType, newWeight, newCountMin, newCountMax);

            //Update the renderization
            BiomeSpawns_UpdateEntriesRenderization(biomeSpawns_currentSelectedDividerKey);

            //Show dirt
            if (this.Title.Contains("*") == false)
                this.Title = (this.Title + "*");
        }

        private void BiomeSpawns_RemoveFromCurrentDivider()
        {
            //Remove the selected entries
            List<string> idsOfEntriesToRemove = new List<string>();
            foreach (SpawnItem item in instantiatedSpawnItems)
                if (item.check.IsChecked == true)
                    idsOfEntriesToRemove.Add(item.idTxt.Text);
            biomeMobWeight.RemoveEntriesOfDividerKey(biomeSpawns_currentSelectedDividerKey, idsOfEntriesToRemove.ToArray());

            //Update the renderization
            BiomeSpawns_UpdateEntriesRenderization(biomeSpawns_currentSelectedDividerKey);

            //Show dirt
            if (this.Title.Contains("*") == false)
                this.Title = (this.Title + "*");
        }

        private void BiomeSpawns_SaveChangesToFile()
        {
            //Save the changes
            biomeMobWeight.SaveFileChanges();

            //Show warning
            MessageBox.Show("The changes was saved to file \"BiomeMobWeight.csv\"!", "Sucess", MessageBoxButton.OK, MessageBoxImage.Information);

            //Remove dirt
            this.Title = this.Title.Replace("*", "");
        }

        private void BiomeSpawns_AddToAllDividers(string type, string creatureId, string weight, string countMin, string countMax)
        {
            //Add thew new entrie on all dividers
            string[] biomesThatReceived = biomeMobWeight.AddEntrieToAllDividers(type, creatureId, weight, countMin, countMax);

            //Update the renderization
            BiomeSpawns_UpdateRenderization();

            //Move the spawn scroll view to top
            spawnScroll.ScrollToTop();

            //Show warning of added
            StringBuilder biomesAdded = new StringBuilder();
            int itemsPerLineCount = 0;
            foreach(string item in biomesThatReceived)
            {
                //Increase items per line
                itemsPerLineCount += 1;

                //Add the item
                if (itemsPerLineCount > 1)
                    biomesAdded.Append((", " + item.Split("/")[1]));
                if (itemsPerLineCount == 1)
                    biomesAdded.Append(item.Split("/")[1]);
            }
            if (biomesThatReceived.Length == 0)
                biomesAdded.Append("None.");
            MessageBox.Show(("The new Entrie was added to " + biomesThatReceived.Length + " Biomes and was added in following Biomes...\n\n" + biomesAdded.ToString()), "Add Result", MessageBoxButton.OK);

            //Show dirt
            if (this.Title.Contains("*") == false)
                this.Title = (this.Title + "*");
        }

        private void BiomeSpawns_AddToAllDividersWhereHaveSpawnEntrie(string type, string creatureId, string weight, string countMin, string countMax, string whereHaveCreatureId)
        {
            //Add thew new entrie on all dividers that have a creature id
            string[] biomesThatReceived = biomeMobWeight.AddEntrieToAllDividersWhereHaveCreatureId(type, creatureId, weight, countMin, countMax, whereHaveCreatureId);

            //Update the renderization
            BiomeSpawns_UpdateRenderization();

            //Move the spawn scroll view to top
            spawnScroll.ScrollToTop();

            //Show warning of added
            StringBuilder biomesAdded = new StringBuilder();
            int itemsPerLineCount = 0;
            foreach (string item in biomesThatReceived)
            {
                //Increase items per line
                itemsPerLineCount += 1;

                //Add the item
                if (itemsPerLineCount > 1)
                    biomesAdded.Append((", " + item.Split("/")[1]));
                if (itemsPerLineCount == 1)
                    biomesAdded.Append(item.Split("/")[1]);
            }
            if (biomesThatReceived.Length == 0)
                biomesAdded.Append("None.");
            MessageBox.Show(("The new Entrie was added to " + biomesThatReceived.Length + " Biomes where have the Spawns of Creature ID \"" + whereHaveCreatureId + "\" and was added in following Biomes...\n\n" + biomesAdded.ToString()), "Add Result", MessageBoxButton.OK);

            //Show dirt
            if (this.Title.Contains("*") == false)
                this.Title = (this.Title + "*");
        }

        private void BiomeSpawns_EditFromAllDividers(string whereCreatureIdIs, string newType, string newWeight, string newCountMin, string newCountMax)
        {
            //Edit the entries on all dividers where creature id is...
            string[] biomeThatEdited = biomeMobWeight.EditEntriesOnAllDividers(whereCreatureIdIs, newType, newWeight, newCountMin, newCountMax);

            //Update the renderization
            BiomeSpawns_UpdateRenderization();

            //Move the spawn scroll view to top
            spawnScroll.ScrollToTop();

            //Show warning of edited
            StringBuilder biomesEdited = new StringBuilder();
            int itemsPerLineCount = 0;
            foreach (string item in biomeThatEdited)
            {
                //Increase items per line
                itemsPerLineCount += 1;

                //Add the item
                if (itemsPerLineCount > 1)
                    biomesEdited.Append((", " + item.Split("/")[1]));
                if (itemsPerLineCount == 1)
                    biomesEdited.Append(item.Split("/")[1]);
            }
            if (biomeThatEdited.Length == 0)
                biomesEdited.Append("None.");
            MessageBox.Show(("The Entrie was found and edited in " + biomeThatEdited.Length + " Biomes and was edited in following Biomes...\n\n" + biomesEdited.ToString()), "Edit Result", MessageBoxButton.OK);

            //Show dirt
            if (this.Title.Contains("*") == false)
                this.Title = (this.Title + "*");
        }

        private void BiomeSpawns_RemoveFromAllDividers(string whereCreatureIdIs)
        {
            //Remove the entries on all dividers where creature id is...
            string[] biomeThatRemovedOn = biomeMobWeight.RemoveEntriesOnAllDividers(whereCreatureIdIs);

            //Update the renderization
            BiomeSpawns_UpdateRenderization();

            //Move the spawn scroll view to top
            spawnScroll.ScrollToTop();

            //Show warning of edited
            StringBuilder biomesRemovedOn = new StringBuilder();
            int itemsPerLineCount = 0;
            foreach (string item in biomeThatRemovedOn)
            {
                //Increase items per line
                itemsPerLineCount += 1;

                //Add the item
                if (itemsPerLineCount > 1)
                    biomesRemovedOn.Append((", " + item.Split("/")[1]));
                if (itemsPerLineCount == 1)
                    biomesRemovedOn.Append(item.Split("/")[1]);
            }
            if (biomeThatRemovedOn.Length == 0)
                biomesRemovedOn.Append("None.");
            MessageBox.Show(("The Entrie was found and removed of " + biomeThatRemovedOn.Length + " Biomes and was removed of following Biomes...\n\n" + biomesRemovedOn.ToString()), "Remove Result", MessageBoxButton.OK);

            //Show dirt
            if (this.Title.Contains("*") == false)
                this.Title = (this.Title + "*");
        }

        private void BiomeSpawns_SearchEntrieInAllDividers(string whereCreatureIdIs)
        {
            //Search the entries on all dividers where creature id is...
            string[] biomeThatHaveEntrie = biomeMobWeight.SearchEntriesOnAllDividers(whereCreatureIdIs);

            //Show the search result
            new Thread(() => {
                //Wait time
                Thread.Sleep(50);

                //Run on main thread
                Application.Current.Dispatcher.Invoke(new Action(() => { SetInteractionBlockerEnabled(true); }));
            }).Start();
            WindowSearchResults windowSearchResults = new WindowSearchResults(whereCreatureIdIs, biomeThatHaveEntrie);
            windowSearchResults.Closed += (s, e) => { SetInteractionBlockerEnabled(false); };
            windowSearchResults.Show();
        }

        private void BiomeSpawns_ClearFile()
        {
            //Show the interaction blocker
            SetInteractionBlockerEnabled(true);

            //Show warning
            MessageBoxResult result = MessageBox.Show("This will delete the \"BiomeMobWeight.csv\" file.\n\n" +
                                                      "Deleting this file will erase any changes you have made to your Spawns using the Spawn Balance Utility mod. This can be useful if you want to restore the default Spawn settings.\n\n" +
                                                      "After deleting this file, launch the game, start a New World, then close the game and reopen SBUEditor again.\n\n" +
                                                      "Do you want to continue and delete the \"BiomeMobWeight.csv\" file?", "Warning", MessageBoxButton.YesNo);

            //If canceled, cancel here
            if (result != MessageBoxResult.Yes)
            {
                SetInteractionBlockerEnabled(false);
                return;
            }

            //Delete the file
            File.Delete((programDirPath + "/BiomeMobWeight.csv"));

            //Close the program
            Environment.Exit(0);
        }

        //------------------ Structure Spawns ------------------//

        //Private variables
        private StructMobWeight structMobWeight = null;
        private string structureSpawns_currentSelectedDividerKey = "";

        //Core methods

        private void StructureSpawns_Initialize()
        {
            //Load the "StructMobWeight.csv" file
            structMobWeight = new StructMobWeight((programDirPath + "/StructMobWeight.csv"));

            //Prepare the divider add button
            addBtn.Click += (s, e) =>
            {
                //Open the add entrie window
                SetInteractionBlockerEnabled(true);
                WindowAddEntrie windowAddEntrie = new WindowAddEntrie(WindowAddEntrie.AdditionType.ToCurrentDivider, (type, creatureId, weight, countMin, countMax) => {
                    StructureSpawns_AddToCurrentDivider(type, creatureId, weight, countMin, countMax);
                });
                windowAddEntrie.Closed += (s, e) => { SetInteractionBlockerEnabled(false); };
                windowAddEntrie.Show();
            };

            //Prepare the divider edit button
            editBtn.Click += (s, e) =>
            {
                //Find the entrie id and current data to edit
                string entrieIdToEdit = "";
                string entrieType = "";
                string entrieWeight = "";
                string entrieCountMin = "";
                string entrieCountMax = "";
                foreach (SpawnItem item in instantiatedSpawnItems)
                    if (item.check.IsChecked == true)
                    {
                        entrieIdToEdit = item.idTxt.Text;
                        entrieType = item.typeTxt.Text;
                        entrieWeight = item.weightTxt.Text;
                        entrieCountMin = item.countMinTxt.Text;
                        entrieCountMax = item.countMaxTxt.Text;
                        break;
                    }

                //Open the edit entrie window
                SetInteractionBlockerEnabled(true);
                WindowEditEntrie windowEditEntrie = new WindowEditEntrie(WindowEditEntrie.EditionType.ToCurrentDivider, entrieIdToEdit, entrieType, entrieWeight, entrieCountMin, entrieCountMax,
                    (whereCreatureIdIs, newType, newWeight, newCountMin, newCountMax) => {
                        StructureSpawns_EditFromCurrentDivider(whereCreatureIdIs, newType, newWeight, newCountMin, newCountMax);
                    });
                windowEditEntrie.Closed += (s, e) => { SetInteractionBlockerEnabled(false); };
                windowEditEntrie.Show();
            };

            //Prepare the remover button
            removeBtn.Click += (s, e) =>
            {
                //Confirm the remotion
                SetInteractionBlockerEnabled(true);
                MessageBoxResult result = MessageBox.Show("Are you sure you want to remove the selected Entries?", "Remove Entries", MessageBoxButton.YesNo);
                SetInteractionBlockerEnabled(false);
                if (result == MessageBoxResult.Yes)
                    StructureSpawns_RemoveFromCurrentDivider();
            };

            //Prepare the save button
            saveFileBtn.Click += (s, e) =>
            {
                //Save the changes to file
                StructureSpawns_SaveChangesToFile();
            };

            //Prepare the search on all dividers button
            searchInAllBtn.Click += (s, e) =>
            {
                //Open the remove entrie window
                SetInteractionBlockerEnabled(true);
                WindowSearchInput windowSearchInput = new WindowSearchInput("minecraft:mob_example", (whereCreatureIdIs) =>
                {
                    StructureSpawns_SearchEntrieInAllDividers(whereCreatureIdIs);
                });
                windowSearchInput.Closed += (s, e) => { SetInteractionBlockerEnabled(false); };
                windowSearchInput.Show();
            };

            //Prepare the clear button
            clearFileBtn.Click += (s, e) =>
            {
                //Clear the file
                StructureSpawns_ClearFile();
            };

            //Update the renderization of the entire file
            StructureSpawns_UpdateRenderization();
        }

        private void StructureSpawns_UpdateRenderization()
        {
            //Update dividers renderization
            StructureSpawns_UpdateDividersRenderization();

            //Auto-select the first divider
            StructureSpawns_UpdateEntriesRenderization(structMobWeight.GetSpawnDictionaryRef().Keys.First());
        }

        private void StructureSpawns_UpdateDividersRenderization()
        {
            //Clear all previously divider rendered
            foreach (DividerItem item in instantiatedDividerItems)
                dividerList.Children.Remove(item);
            instantiatedDividerItems.Clear();

            //Render all dividers
            foreach (string item in structMobWeight.GetSpawnDictionaryRef().Keys)
            {
                //Draw the item on screen
                DividerItem newItem = new DividerItem(this);
                dividerList.Children.Add(newItem);
                instantiatedDividerItems.Add(newItem);

                //Configure it
                newItem.HorizontalAlignment = HorizontalAlignment.Stretch;
                newItem.VerticalAlignment = VerticalAlignment.Top;
                newItem.Width = double.NaN;
                newItem.Height = double.NaN;
                newItem.Margin = new Thickness(0, 8, 0, 0);

                //Inform the data about the divider
                newItem.SetDividerKey(item);
                newItem.RegisterOnClickCallback((key) => {
                    //Change to render the entries of the clicked divider
                    this.StructureSpawns_UpdateEntriesRenderization(key);

                    //Move the spawn scroll view to top
                    spawnScroll.ScrollToTop();
                });
                newItem.Prepare();
            }
        }

        private void StructureSpawns_UpdateEntriesRenderization(string dividerKey)
        {
            //Disable all divider
            foreach (DividerItem item in instantiatedDividerItems)
                item.SetEnabled(false);
            //Enable the selected divider
            foreach (DividerItem item in instantiatedDividerItems)
                if (item.itemName.Text == dividerKey)
                    item.SetEnabled(true);

            //Clear all previously entries rendered
            foreach (SpawnItem item in instantiatedSpawnItems)
                spawnsList.Children.Remove(item);
            instantiatedSpawnItems.Clear();

            //Render all entries
            foreach (StructMobWeight.SpawnData item in structMobWeight.GetSpawnDictionaryRef()[dividerKey])
            {
                //Draw the item on screen
                SpawnItem newItem = new SpawnItem(this);
                spawnsList.Children.Add(newItem);
                instantiatedSpawnItems.Add(newItem);

                //Configure it
                newItem.HorizontalAlignment = HorizontalAlignment.Stretch;
                newItem.VerticalAlignment = VerticalAlignment.Top;
                newItem.Width = double.NaN;
                newItem.Height = double.NaN;
                newItem.Margin = new Thickness(0, 8, 0, 0);

                //Inform the data about the entrie
                newItem.SetOwnerKey(dividerKey);
                newItem.SetType(item.type);
                newItem.SetID(item.id);
                newItem.SetWeight(item.weight);
                newItem.SetCountMin(item.minCount);
                newItem.SetCountMax(item.maxCount);
                newItem.RegisterOnChangeSelectionCallback(() => { ProcessSelection(); });
                newItem.Prepare();
            }

            //Update the status bar
            statusBarTxt.Text = (instantiatedDividerItems.Count + " Structures found. Selected \"" + dividerKey + "\", have " + structMobWeight.GetSpawnDictionaryRef()[dividerKey].Count + " Spawn entries...");

            //Show or hide the empty warn
            if (structMobWeight.GetSpawnDictionaryRef()[dividerKey].Count == 0)
                spawnsEmptyWarn.Visibility = Visibility.Visible;
            if (structMobWeight.GetSpawnDictionaryRef()[dividerKey].Count > 0)
                spawnsEmptyWarn.Visibility = Visibility.Collapsed;

            //Inform the current selected divider key
            structureSpawns_currentSelectedDividerKey = dividerKey;

            //Process current selection
            ProcessSelection();
        }

        private void StructureSpawns_AddToCurrentDivider(string type, string creatureId, string weight, string countMin, string countMax)
        {
            //Add the new entrie
            bool added = structMobWeight.AddEntrieOnDividerKey(structureSpawns_currentSelectedDividerKey, type, creatureId, weight, countMin, countMax);

            //Update the renderization
            StructureSpawns_UpdateEntriesRenderization(structureSpawns_currentSelectedDividerKey);

            //If not added, warn
            if (added == false)
                MessageBox.Show("New Entry not added. There is probably already an Entry with this Creature ID in this Structure.", "Not Added", MessageBoxButton.OK);
            //If added, move to end
            if (added == true)
                spawnScroll.ScrollToEnd();

            //Show dirt
            if (this.Title.Contains("*") == false)
                this.Title = (this.Title + "*");
        }

        private void StructureSpawns_EditFromCurrentDivider(string whereCreatureIdIs, string newType, string newWeight, string newCountMin, string newCountMax)
        {
            //Edit the entrie
            structMobWeight.EditEntrieOnDividerKey(structureSpawns_currentSelectedDividerKey, whereCreatureIdIs, newType, newWeight, newCountMin, newCountMax);

            //Update the renderization
            StructureSpawns_UpdateEntriesRenderization(structureSpawns_currentSelectedDividerKey);

            //Show dirt
            if (this.Title.Contains("*") == false)
                this.Title = (this.Title + "*");
        }

        private void StructureSpawns_RemoveFromCurrentDivider()
        {
            //Remove the selected entries
            List<string> idsOfEntriesToRemove = new List<string>();
            foreach (SpawnItem item in instantiatedSpawnItems)
                if (item.check.IsChecked == true)
                    idsOfEntriesToRemove.Add(item.idTxt.Text);
            structMobWeight.RemoveEntriesOfDividerKey(structureSpawns_currentSelectedDividerKey, idsOfEntriesToRemove.ToArray());

            //Update the renderization
            StructureSpawns_UpdateEntriesRenderization(structureSpawns_currentSelectedDividerKey);

            //Show dirt
            if (this.Title.Contains("*") == false)
                this.Title = (this.Title + "*");
        }

        private void StructureSpawns_SaveChangesToFile()
        {
            //Save the changes
            structMobWeight.SaveFileChanges();

            //Show warning
            MessageBox.Show("The changes was saved to file \"StructMobWeight.csv\"!", "Sucess", MessageBoxButton.OK, MessageBoxImage.Information);

            //Remove dirt
            this.Title = this.Title.Replace("*", "");
        }
    
        private void StructureSpawns_SearchEntrieInAllDividers(string whereCreatureIdIs)
        {
            //Search the entries on all dividers where creature id is...
            string[] structureThatHaveEntrie = structMobWeight.SearchEntriesOnAllDividers(whereCreatureIdIs);

            //Show the search result
            new Thread(() => {
                //Wait time
                Thread.Sleep(50);

                //Run on main thread
                Application.Current.Dispatcher.Invoke(new Action(() => { SetInteractionBlockerEnabled(true); }));
            }).Start();
            WindowSearchResults windowSearchResults = new WindowSearchResults(whereCreatureIdIs, structureThatHaveEntrie);
            windowSearchResults.Closed += (s, e) => { SetInteractionBlockerEnabled(false); };
            windowSearchResults.Show();
        }

        private void StructureSpawns_ClearFile()
        {
            //Show the interaction blocker
            SetInteractionBlockerEnabled(true);

            //Show warning
            MessageBoxResult result = MessageBox.Show("This will delete the \"StructMobWeight.csv\" file.\n\n" +
                                                      "Deleting this file will erase any changes you have made to your Spawns using the Spawn Balance Utility mod. This can be useful if you want to restore the default Spawn settings.\n\n" +
                                                      "After deleting this file, launch the game, start a New World, then close the game and reopen SBUEditor again.\n\n" +
                                                      "Do you want to continue and delete the \"StructMobWeight.csv\" file?", "Warning", MessageBoxButton.YesNo);

            //If canceled, cancel here
            if (result != MessageBoxResult.Yes)
            {
                SetInteractionBlockerEnabled(false);
                return;
            }

            //Delete the file
            File.Delete((programDirPath + "/StructMobWeight.csv"));

            //Close the program
            Environment.Exit(0);
        }
    }
}
