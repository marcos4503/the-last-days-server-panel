﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SBUEditor
{
    /*
     * This is the script responsible by the window of entrie search result
    */

    public partial class WindowSearchResults : Window
    {
        //Core methods

        public WindowSearchResults(string creatureIdToSearch, string[] searchResult)
        {
            //Initialize the Window
            InitializeComponent();

            //Show the search term
            idTxt.Text = creatureIdToSearch;

            //Show the result
            countTxt.Text = "Entries with the requested Creature ID were found in " + searchResult.Length + " Dividers...";
            StringBuilder resultText = new StringBuilder();
            foreach (string item in searchResult)
            {
                if (item.Contains("/") == true)
                    resultText.Append("\n- " + item.Split("/")[1]);
                if (item.Contains("/") == false)
                    resultText.Append("\n- " + item);
            }
            if (searchResult.Length == 0)
                resultText.Append("\n- None");
            resultTxt.Text = resultText.ToString().Remove(0, 1);
        }
    }
}
